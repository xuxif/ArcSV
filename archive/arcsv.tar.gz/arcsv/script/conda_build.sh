if [ -z ${CONDA_BUILD+x} ]; then
    source /home/hjb_xxf/anaconda3/conda-bld/arcsv_1691914773566/work/build_env_setup.sh
fi
mkdir -p $PREFIX/bin
cp * $PREFIX/bin/
chmod +x $PREFIX/bin/*