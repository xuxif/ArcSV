ac=$1
arc_name=`echo $1 |perl -npe "s/.*\///"|perl -npe "s/\..*//"`
bam_file_pre=$2
over_len=$3
if [ -z "$var" ]
then
        over_len=50
fi
mkdir -p BKsArcInBAM_oneBP

bedtools intersect -b <( cat BKSinBAM_oneBP/${bam_file_pre}.tsv|pos2bed 1|grep -v "\-") -a $ac -wa -wb | BKinCheck_len.pl|pos2bed 1 |sort -k1,1 -k2,2n |cut -f1-5,7,9 |bed2pos |cut -f2-|perl -F'\t' -alne 'print "$F[4]\tBK_$F[1]=$F[0];EVIDENCE_$F[1]_ARCHAIC=$F[2];EVIDENCE_$F[1]_MODERN=$F[3]";'|perl -npe "s/:/\t/"|pos2bed 2 |sort -k1,1 -k2,2n |bedtools merge -delim ';' -c 4 -o collapse |bed2pos >BKsArcInBAM_oneBP/${bam_file_pre}_$arc_name.tsv
echo "$bam_file_pre $arc_name finished!"
