bam_file=$1
bam_file_pre=`echo $bam_file|perl -npe "s/.*\///" |perl -npe "s/\..*//"`
ran_num=$2
input_gt=$3
REF=$4
arc_db=$5
arc_name=`echo $arc_db|perl -npe "s/.*\///" |perl -npe "s/\..*//"`
if [[  -d "regions_$ran_num" ]]
then
	rm -rf regions_$ran_num split_softclipped_$ran_num split_softclipped_sort_$ran_num head_$ran_num.sam
fi

mkdir -p regions_$ran_num split_softclipped_$ran_num split_softclipped_sort_$ran_num BKSinBAM_oneBP 
samtools view -T $REF -H $bam_file  >head_$ran_num.sam

input_is_vcf=0
bcftools view -h $input_gt >/dev/null 2>&1
if [[ $? -eq 0 ]]
then
	input_is_vcf=1
	echo "The input SV is VCF format !" 
	bcftools query -f '%CHROM:%POS\t%CHROM\t%POS\t%INFO/END\n' $input_gt  >${bam_file_pre}_input.bed 2>&1
	if [[ $? -eq 0 ]]
	then
		echo "The input SV contained 'END' information!" 
	else
		echo "The input SV missed 'END' information!" 
		bcftools query -f '%CHROM:%POS\t%CHROM\t%POS\n' $input_gt  >${bam_file_pre}_input.bed 2>&1
	fi
else
	echo "The input SV is position format with tab!" 
	cat $input_gt |perl -F'\t' -alne 'print "$F[0]:$F[1]\t$_";' >${bam_file_pre}_input.bed
fi

cat ${bam_file_pre}_input.bed|perl -F'\t' -alne '$start=$F[2]-50;$start2=$F[3]-50;;$end=$F[2]+50;$end2=$F[3]+50;if($start>0){print "$F[1]:$start-$end\t$F[0]";} if($start2>0){print "$F[1]:$start2-$end2\t$F[0]";}' |xargs -I{} -P 40 generateBKSinBam.pl {} $ran_num $bam_file $REF >/dev/null
echo "generate record finished!"

#HG002_${record}_mapClipL.sam
ls split_softclipped_$ran_num |grep "_mapClip"|while read file;do record=`echo $file|perl -npe "s/HG002_//;s/_mapClip.*//;s/[:\-]/\t/g" |bed2pos|perl -npe "s/\t/:/"`;extractSoftclipped -l 7 <(cat head_${ran_num}.sam split_softclipped_$ran_num/$file ) |fastqToBKS.pl|perl -npe "s/$/\t$record/";done >BKSinBAM_oneBP/${bam_file_pre}.tsv
echo "Breakpoint detected finished!!"

generateBKSinBam_each.sh $arc_db $bam_file_pre $over_len

if [[ $input_is_vcf -eq 1 ]]
then
	cat <(bcftools view -h $input_gt |sed -n '1,/^##INFO/p'|grep -v "^##INFO") \
	<(echo -e "##INFO=<ID=BK_left,Number=1,Type=Integer,Description=\"Position of soft-clipped read in the left\">\n##INFO=<ID=BK_right,Number=1,Type=Integer,Description=\"Position of soft-clipped read in the right\">\n##INFO=<ID=EVIDENCE_left_ARCHAIC,Number=1,Type=Integer,Description=\"Count of soft-clipped read in the left , archaic human bam file\">\n##INFO=<ID=EVIDENCE_right_ARCHAIC,Number=1,Type=Integer,Description=\"Count of soft-clipped read in the right , archaic human bam file\">\n##INFO=<ID=EVIDENCE_left_MODERN,Number=1,Type=Integer,Description=\"Count of soft-clipped read in the left , modern human bam file\">\n##INFO=<ID=EVIDENCE_right_MODERN,Number=1,Type=Integer,Description=\"Count of soft-clipped read in the right , modern human bam file\">") \
	<(bcftools view -h $input_gt |sed -n '/^##INFO/,$p') \
	<( bedtools intersect -a <(cat BKsArcInBAM_oneBP/${bam_file_pre}_$arc_name.tsv |pos2bed 1) -b <(bcftools view -H $input_gt|pos2bed 1) -wa -wb |perl -F'\t' -alne '$F[12]="$F[3];$F[12]";print join("\t",@F);' |cut -f5-|bed2pos) >ArcSV_${bam_file_pre}_$arc_name.vcf
else
	mv BKsArcInBAM_oneBP/${bam_file_pre}_$arc_name.tsv ArcSV_${bam_file_pre}_$arc_name.tsv
fi

rm -rf split_softclipped_$ran_num split_softclipped_sort_$ran_num head_$ran_num.sam regions_$ran_num  ${bam_file_pre}_input.bed BKsArcInBAM_oneBP  BKSinBAM_oneBP

