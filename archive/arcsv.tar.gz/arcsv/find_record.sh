grep "$1" ~/1kGP_SV_vcf/1kGP.bed|wc -l 
