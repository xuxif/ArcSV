#! /usr/bin/env perl
while(<STDIN>)
{
	chomp();
	$read_name=$_;
	$read_base=<STDIN>;chomp($read_base);
	<STDIN>;<STDIN>;
	@fields=split(/\|/,$read_name);
	$dir="left";
	if($fields[6]=~/S$/)
	{
		$dir="right";
	}
	print "$fields[3]\t$fields[8]\t$fields[6]\t$dir\t$read_base\t$fields[1]\n";
}
	
	
